DEBUG = True

SERVER_NAME = 'localhost:8000'

CELERY_BROKER_URL='redis://localhost:6379'
CELERY_RESULT_BACKEND='redis://localhost:6379'

