import atexit
import threading
from flask import Blueprint
from flask.json import jsonify
from hodor.blueprints.pcap.tasks import pcap_learn_listener
from hodor.blueprints.pcap.tasks import pcap_predict_listener

pcap = Blueprint('pcap', __name__)

cond = threading.Event()

pcap_learn_thread = threading.Thread(target=pcap_learn_listener, args=(cond, ))
pcap_learn_thread.daemon = True

pcap_predict_thread = threading.Thread(target=pcap_predict_listener, args=(cond, ))
pcap_predict_thread.daemon = True

now_learning = False

@pcap.route('/api/pcap_learn/<val>', methods=['GET'])
def pcap_learn_start(val):
		bval = str(val)
		result = "Invalid input"
		if bval == 'True' and pcap_learn_thread.isAlive() == False:
			result = "PCAP learn listener started ..."
			pcap_learn_thread.start()
		elif bval == 'False' and pcap_learn_thread.isAlive() == True:
			result = "PCAP learn listener stopped ..."
			now_learning = True
			cond.set()
		else:
			print "bval", bval, pcap_learn_thread.isAlive()
		return jsonify(result = result)

@pcap.route('/api/pcap_predict/<val>', methods=['GET'])
def pcap_predict_start(val):
		bval = str(val)
		result = "Invalid input"
		if bval == 'True' and pcap_predict_thread.isAlive() == False:
			result = "PCAP learn listener started ..."
			pcap_predict_thread.start()
		else:
			result = "Still learning ..."
		return jsonify(result = result)


@pcap.route('/api/pcap_is_running', methods=['GET'])
def pcap_is_learn_running():
		learn = False
		predict = False
		if pcap_learn_thread.isAlive():
			learn = True
		if pcap_predict_thread.isAlive():
			predict = True
		return jsonify(learn = learn, predict = predict)

@atexit.register
def cleanup():
	print "Removing listener"
	cond.set()