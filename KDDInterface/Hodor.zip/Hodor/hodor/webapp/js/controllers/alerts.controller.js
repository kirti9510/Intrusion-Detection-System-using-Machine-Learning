var app = angular.module('AF');

app.controller('alertsCtrl', function ($scope, AlertsResource) {

});