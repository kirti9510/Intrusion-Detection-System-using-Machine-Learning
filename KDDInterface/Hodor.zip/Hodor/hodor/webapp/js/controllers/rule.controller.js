var app = angular.module('AF');

app.controller('ruleCtrl', function ($scope, RuleResource) {

});
