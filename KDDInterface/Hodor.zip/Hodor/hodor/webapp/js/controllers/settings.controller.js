var app = angular.module('AF');

app.controller('settingsCtrl', function ($scope, $state, SettingsResource) {

});
