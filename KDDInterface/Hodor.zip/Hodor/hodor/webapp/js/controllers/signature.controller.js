var app = angular.module('AF');

app.controller('signatureCtrl', function ($scope, $state, SignatureResource) {

});
