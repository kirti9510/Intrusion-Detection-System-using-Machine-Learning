'use strict';

angular.module('AF')
    .factory('ManageResource', function ($resource) {
        return $resource('/api/manage/:id', {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    data = angular.fromJson(data);
                    return data;
                }
            },
            'update': { method:'PUT' }
        });
    });